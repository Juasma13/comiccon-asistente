# Comic-Con Málaga Asistente

Web app basada en Streamlit para ayudar a los asistentes del evento.